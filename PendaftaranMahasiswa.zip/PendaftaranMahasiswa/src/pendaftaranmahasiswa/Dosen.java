package pendaftaranmahasiswa;

public class Dosen extends User {
    private String iddosen;

    public Dosen(String nama, String email, String password, String type,String iddosen) {
        super(nama, email, password, type);
        this.iddosen=iddosen;
    }

    public String getIddosen() {
        return iddosen;
    }

    public void setIddosen(String iddosen) {
        this.iddosen = iddosen;
    }
}
