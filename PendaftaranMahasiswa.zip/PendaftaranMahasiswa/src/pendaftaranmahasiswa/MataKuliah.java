package pendaftaranmahasiswa;

public class MataKuliah {
    private String kodematkul;
    private String namamatkul;
    private boolean disetujui;
    public MataKuliah(String kodematkul, String namamatkul){
        this.kodematkul=kodematkul;
        this.namamatkul=namamatkul;
        this.disetujui=false;
    }

    public String getKodematkul() {
        return kodematkul;
    }

    public void setKodematkul(String kodematkul) {
        this.kodematkul = kodematkul;
    }

    public String getNamamatkul() {
        return namamatkul;
    }

    public void setNamamatkul(String namamatkul) {
        this.namamatkul = namamatkul;
    }

    public boolean isDisetujui() {
        return disetujui;
    }

    public void setDisetujui(boolean disetujui) {
        this.disetujui = disetujui;
    }
    
}
