
package pendaftaranmahasiswa;

import java.util.Scanner;

public class PendaftaranMahasiswa {

    public static Mahasiswa loginmahasiswa(Mahasiswa[] mahasiswa, String email, String password){
        for (int i = 0; i <= mahasiswa.length; i++) {
                if(mahasiswa[i].getEmail().equalsIgnoreCase(email) && mahasiswa[i].getPassword().equalsIgnoreCase(password)){
                    return mahasiswa[i];
                }
        }
        return null;
    }
    public static Dosen logindosen(Dosen[] dosen, String email, String password){
        for (int i = 0; i < dosen.length; i++) {
                if(dosen[i].getEmail().equalsIgnoreCase(email) && dosen[i].getPassword().equalsIgnoreCase(password)){
                    return dosen[i];
                }
        }
        return null;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Mahasiswa[] mahasiswa=new Mahasiswa[1];
        mahasiswa[0]=new Mahasiswa("lukman", "lukmansttb@gmail.com", "1234", "mahasiswa","16112010");
        Dosen[] dosen=new Dosen[1];
        dosen[0]=new Dosen("frans", "saya@gmail.com", "1234", "dosen","163130236");
        System.out.println("Login ");
        System.out.println("1. Login mahasiswa");
        System.out.println("2. Login dosen");
        Scanner scan = new Scanner(System.in);
        int i = scan.nextInt();
        if(i==1){
            
            System.out.println("masukan email ");
            String email=scan.next();
            System.out.println("masukan password ");
            String password=scan.next();
            Mahasiswa login_mahasiswa;
            login_mahasiswa = loginmahasiswa( mahasiswa, email, password);
            while(login_mahasiswa==null){
                System.out.println("password atau emai yang dimasukan salah ");
                System.out.println("masukan email ");
                email=scan.next();
                System.out.println("masukan password ");
                password=scan.next();
                login_mahasiswa = loginmahasiswa( mahasiswa, email, password);
            }
            System.out.println("login mahasiswa berhasil");
            System.out.println("Selamat datang "+login_mahasiswa.getNama());            
        }else{
            System.out.println("masukan email ");
            String email=scan.next();
            System.out.println("masukan password ");
            String password=scan.next();
            Dosen login_dosen;
            login_dosen = logindosen( dosen, email, password);
            while(login_dosen==null){
                System.out.println("password atau email yang dimasukan salah ");
                System.out.println("masukan email ");
                email=scan.next();
                System.out.println("masukan password ");
                password=scan.next();
                login_dosen = logindosen( dosen, email, password);

            }
            System.out.println("login dosen berhasil");
            System.out.println("Selamat datang "+login_dosen.getNama());            
        }


    }
    
}
