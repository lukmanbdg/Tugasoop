package pendaftaranmahasiswa;

public class Mahasiswa extends User {
    private String nim;
    public Mahasiswa(String nama, String email, String password, String type,String nim) {
        super(nama, email, password, type);
        this.nim=nim;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }
   
    
    
}
