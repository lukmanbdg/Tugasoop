package pendaftaranmahasiswa;

public class Kelas {
    
}
